Galaxy name = Andromeda
Galaxy black hole mass = 1e5
Galaxy redshift = 0
Galaxy brightness variabiliy = None
