Galaxy name = ARK 120
Galaxy black hole mass = 150e6
Galaxy brightness variabiliy = Low

Galaxy redshift = 
