Galaxy name = GSN 069
Galaxy black hole mass = 1e5
Galaxy brightness variabiliy = High

Galaxy redshift =
