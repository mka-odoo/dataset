Galaxy name = IRAS 13224-3809
Galaxy black hole mass = 1.9e6
Galaxy brightness variabiliy = High and random

Galaxy redshift = 
