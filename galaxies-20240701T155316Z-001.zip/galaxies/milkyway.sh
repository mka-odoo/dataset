Galaxy name = Milky Way

The Milky Way is estimated to contain 100-400 billion stars.

At the center of the Milky Way is a supermassive black
hole called "Sagittarius A*", with a mass of approximately
4000 solar masses.
