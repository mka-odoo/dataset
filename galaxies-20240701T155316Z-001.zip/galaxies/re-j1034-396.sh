Galaxy name = RE J1034 + 396
Galaxy black hole mass = 2e6
Galaxy brightness variabiliy = High and periodic

Galaxy redshift =
